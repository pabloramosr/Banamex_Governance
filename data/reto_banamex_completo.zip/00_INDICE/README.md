# Corpus Banamex para RAG de crédito

Compilación ampliada el 11 de noviembre de 2026 con documentos públicos oficiales de Banamex, Banco de México y la Cámara de Diputados.

El paquete contiene 59 PDF. La ampliación de cuentas, nómina y ahorro agrega 11 PDF: 8 documentos oficiales descargados y 3 fichas de contexto derivadas de páginas oficiales.

## Contenido

- `00_Contratos_Maestros`: contratos de adhesión vigentes. Los contratos idénticos publicados bajo distintos nombres se conservaron una sola vez para evitar duplicidad semántica en el RAG.
- `01_Anexos_Comisiones`: comisiones, penalizaciones, disposiciones de efectivo y costos por producto.
- `02_Folletos_Productos`: requisitos públicos, beneficios, CAT y características comerciales.
- `03_Terminos_Beneficios`: condiciones específicas de programas y tarjetas con socios.
- `04_Otros_Creditos_Banamex`: Crédito Personal, Crédito Nómina y Crédito Hipotecario.
- `05_Marco_Normativo`: leyes federales y circulares compiladas de Banco de México.
- `06_Cuentas_Nomina_Ahorro`: contratos de captación, comisiones, Cuenta Switch, MiCuenta, Cuenta Priority, Cuenta Base, nómina, portabilidad, Ahorro Fácil y Pagaré. Las fichas de contexto web son resúmenes derivados y conservan la URL y fecha de consulta; no sustituyen al contrato ni al anexo oficial.

## Prioridad sugerida en el RAG

1. Normativa y contratos: autoridad 5.
2. Anexos de comisiones: autoridad 4.
3. Términos particulares: autoridad 3.
4. Folletos y páginas comerciales: autoridad 2.

## Reglas de uso

- La respuesta debe citar documento, página, cláusula o artículo.
- Los requisitos públicos permiten determinar compatibilidad preliminar, no garantizar aprobación.
- La aprobación depende del análisis crediticio, capacidad de pago, historial y políticas internas del banco.
- CAT, tasas, promociones y comisiones deben validarse contra su vigencia antes de responder.
- No mezclar documentos históricos con vigentes sin metadatos temporales.
- Distinguir entre cuenta de nómina y Crédito Nómina: recibir el salario puede habilitar una evaluación u oferta, pero no garantiza la aprobación del crédito.
- Para portabilidad, separar banco origen, cuenta receptora, plazo operativo y retenciones por obligaciones previas.

El archivo `inventario_documentos.csv` contiene ruta, categoría, páginas, tamaño, hash SHA-256, prioridad y URL oficial de cada documento.
